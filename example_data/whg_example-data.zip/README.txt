Example data files for WHG upload (2020-12-09)

Linked Places format (JSON-LD based)
	From HGIS de las Indias (https://www.hgis-indias.net/) 
	* lugares_20.jsonld: HGIS de las Indias settlements
	* lugares_60.jsonld: HGIS de las Indias settlements

LP-TSV format (tab-delimited)
	* diamonds135.tsv : 135 sample records mainly from Indonesia
	* croniken.tsv: 181 sample records from the Baltics and Poland
	* template-places.tsv: 7 varied records from the template spreadsheet

Spreadsheet templates
Contain all valid columns + 7 sample records and codebook
	* LP-TSV_template.xlsx
	* LP-TSV_template.ods