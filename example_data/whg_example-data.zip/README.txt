Example data files (2020-07-25)

From HGIS de las Indias (https://www.hgis-indias.net/) 

	* lugares_60_1.jsonld: HGIS de las Indias settlements

	* lugares_60_2.jsonld: HGIS de las Indias settlements


Other

	* diamonds135.tsv : 135 sample records mainly from Indonesia
