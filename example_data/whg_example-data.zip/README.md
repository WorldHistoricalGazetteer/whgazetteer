## Example data files (2020-07-25)

### [HGIS de las Indias](https://www.hgis-indias.net/) 

**lugares\_60_1.jsonld**: 60 HGIS de las Indias settlements

**lugares\_60_2.jsonld**: 60 more HGIS de las Indias settlements


### Other

**diamonds135.tsv**: 135 sample records mainly from Indonesia
