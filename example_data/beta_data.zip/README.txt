Example data files (2019-10-21)

From HGIS de las Indias (https://www.hgis-indias.net/) 

	* lugares_20.jsonld: settlements

	* lugares_60_1.jsonld: HGIS de las Indias settlements

	* lugares_60_2.jsonld: HGIS de las Indias settlements

	* territorios_03.jsonld: HGIS de las Indias admin territories

	* territorios_05.jsonld: HGIS de las Indias admin territories

Other

	* epirus_60.tsv* : Ottoman era Greek places from Ali Pasha papers

	* gncities50.tsv* : 50 large cities from GeoNames

	* topostext_07.jsonld: ToposText (Greece)

	* ne_mountains_60.tsv: Natural Earth mountains

	* alcedo_200.tsv: "Alcedo Gazetteer" Diccionario geográfico-histórico de las Indias Occidentales (1789). * NOTE: NO GEOMETRY; difficult to reconcile.

